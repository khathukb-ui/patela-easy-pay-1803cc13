import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Home, CreditCard, ArrowRight, Smartphone } from "lucide-react";

export default function DeviceSuccess() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen patela-app-bg flex flex-col pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)] items-center justify-center px-6">
      <div className="flex flex-col items-center text-center animate-fade-in">
        {/* Success Animation */}
        <div className="relative mb-4">
          <div className="w-24 h-24 rounded-full bg-success/10 flex items-center justify-center">
            <CheckCircle2 className="h-12 w-12 text-success" />
          </div>
          <div className="absolute inset-0 rounded-full border-4 border-success animate-ping opacity-20" />
        </div>

        <h1 className="text-3xl font-bold text-foreground mb-1">
          Device Paired!
        </h1>
        <p className="text-muted-foreground text-base mb-4 max-w-xs">
          Your Patela machine is connected and ready to accept payments
        </p>

        {/* Device Summary Card */}
        <div className="w-full max-w-sm bg-card rounded-xl patela-shadow-md overflow-hidden mb-4">
          <div className="patela-gradient-primary p-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <Smartphone className="h-6 w-6 text-primary-foreground" />
              </div>
              <div className="text-left">
                <p className="text-primary-foreground/80 text-sm">Paired Device</p>
                <p className="text-primary-foreground font-bold text-lg">FP9320</p>
              </div>
            </div>
          </div>
          <div className="p-4">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground text-base">Status</span>
              <span className="flex items-center gap-2 text-success font-semibold text-base">
                <CheckCircle2 className="h-5 w-5" />
                Connected
              </span>
            </div>
          </div>
        </div>

        {/* What's Next */}
        <div className="w-full max-w-sm mb-4">
          <h3 className="font-semibold text-foreground mb-2 text-left text-base">Ready to go!</h3>
          <div className="space-y-2">
            <div className="flex items-center gap-2 p-2.5 bg-muted/50 rounded-lg">
              <div className="w-7 h-7 rounded-full bg-success/10 flex items-center justify-center">
                <CheckCircle2 className="h-4 w-4 text-success" />
              </div>
              <span className="text-foreground text-base">Phone verified</span>
            </div>
            <div className="flex items-center gap-2 p-2.5 bg-muted/50 rounded-lg">
              <div className="w-7 h-7 rounded-full bg-success/10 flex items-center justify-center">
                <CheckCircle2 className="h-4 w-4 text-success" />
              </div>
              <span className="text-foreground text-base">Bank account linked</span>
            </div>
            <div className="flex items-center gap-2 p-2.5 bg-muted/50 rounded-lg">
              <div className="w-7 h-7 rounded-full bg-success/10 flex items-center justify-center">
                <CheckCircle2 className="h-4 w-4 text-success" />
              </div>
              <span className="text-foreground text-base">Device connected</span>
            </div>
          </div>
        </div>

        {/* Action */}
        <Button 
          variant="default"
          size="xl" 
          className="w-[300px] shadow-md hover:shadow-lg transition-all duration-200 active:scale-95"
          onClick={() => navigate("/home")}
        >
          <CreditCard className="mr-2 h-5 w-5" />
          Start Taking Payments
        </Button>
      </div>
    </div>
  );
}
